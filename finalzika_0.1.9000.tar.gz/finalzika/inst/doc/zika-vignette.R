## ------------------------------------------------------------------------
library('finalzika')

## ------------------------------------------------------------------------
library(sf)

## ------------------------------------------------------------------------
imp=getdata("C:/rpackage/finalzika/inst/brazika_state.shp")

## ------------------------------------------------------------------------
library(animation)
library(shiny)
library(colorspace)

## ------------------------------------------------------------------------
finalzika::animate.cw_polygon()
#This function depends on another function called 'looper' to create the video by looping over the required variables in 'imp'.

## ------------------------------------------------------------------------
library(readxl)
library(tibble)

## ------------------------------------------------------------------------
xl = imp_xl("C:/rpackage/finalzika/inst/brazil_state1.xls")

## ------------------------------------------------------------------------
library(tidyr)
library(dplyr)

## ------------------------------------------------------------------------
timp_xl <- xl %>%
   gather('Week1', 'Week2', 'Week3', 'Week4', 'Week5', 'Week6', 'Week7', 'Week8', 'Week9',
          'Week10', 'Week11', 'Week12', 'Week13', 'Week14', 'Week15', 'Week16', 'Week17',
          'Week18', 'Week19', 'Week20', 'Week21', 'Week22', 'Week23', 'Week24', 'Week25',
          'Week26', 'Week27', 'Week28', 'Week29', 'Week30', 'Week31', 'Week32', 'Week33',
          'Week34', 'Week35', 'Week36', 'Week37', 'Week38', 'Week39', 'Week40', 'Week41',
          'Week42', 'Week43', 'Week44', 'Week45', 'Week46', 'Week47', 'Week48',  'Week49',
          key = "Timeframe", value = "Zikacases")

## ------------------------------------------------------------------------
#User should assign the function 'sum_timp_xl()' to the variable sum_timp.
 sum_timp <- timp_xl %>%
    summarise(Max = max(Zikacases),
              SD = sd(Zikacases),
              Mean = mean(Zikacases),
              Min = min(Zikacases),
              Median = median(Zikacases),
              Var = var(Zikacases))

## ------------------------------------------------------------------------
# User should ssign this function 'pop_infected()' to any unused variable.
v = pop_infected()

## ------------------------------------------------------------------------
library(ggplot2)

## ------------------------------------------------------------------------
plottidy_impxl()

